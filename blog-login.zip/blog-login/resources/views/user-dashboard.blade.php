<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>user Dashboard</title>
</head>
<body>
<h1> Welcome Users</h1>
 <a href="{{ route('user-logout') }}">Logout</a>
</body>
</html>