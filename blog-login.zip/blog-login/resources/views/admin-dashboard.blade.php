<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin Dashboard</title>
</head>
<body>
<h1> Welcome Admins</h1>
<a href="{{ route('admin-logout') }}">Logout</a>
</body>
</html>